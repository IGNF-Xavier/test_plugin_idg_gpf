<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>@default</name>
    <message>
        <location filename="../../toolbelt/browser.py" line="51"/>
        <source>Settings...</source>
        <translation type="obsolete">Paramètres...</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="14"/>
        <source>Form</source>
        <translation>Formulaire</translation>
    </message>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="128"/>
        <source>Miscellaneous</source>
        <translation>Divers</translation>
    </message>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="205"/>
        <source>Report an issue</source>
        <translation>Signaler un bug</translation>
    </message>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="149"/>
        <source>Version used to save settings:</source>
        <translation type="obsolete">Version utilisées pour sauvegarder la configuration:</translation>
    </message>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="155"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="180"/>
        <source>Reset setttings to factory defaults</source>
        <translation>Réinitialiser les paramètres par défaut</translation>
    </message>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="66"/>
        <source>Default plateforms</source>
        <translation>Plateformes IDG</translation>
    </message>
    <message>
        <location filename="../../gui/dlg_settings.ui" line="73"/>
        <source>Custom plateforms</source>
        <translation>Plateformes supplémentaires</translation>
    </message>
</context>
<context>
    <name>IdgPlugin</name>
    <message>
        <location filename="../../plugin_main.py" line="89"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../../plugin_main.py" line="98"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
</context>
<context>
    <name>LayerItem</name>
    <message>
        <location filename="../../toolbelt/browser.py" line="195"/>
        <source>Show metadata</source>
        <translation>Voir les métadonnées</translation>
    </message>
    <message>
        <location filename="../../toolbelt/browser.py" line="201"/>
        <source>Display layer</source>
        <translation>Afficher la couche</translation>
    </message>
</context>
<context>
    <name>PlatformCollection</name>
    <message>
        <location filename="../../toolbelt/browser.py" line="134"/>
        <source>Hide</source>
        <translation>Masquer</translation>
    </message>
</context>
<context>
    <name>RootCollection</name>
    <message>
        <location filename="../../toolbelt/browser.py" line="55"/>
        <source>Settings...</source>
        <translation>Paramètres...</translation>
    </message>
    <message>
        <location filename="../../toolbelt/browser.py" line="65"/>
        <source>Plateforms</source>
        <translation>Plateformes</translation>
    </message>
    <message>
        <location filename="../../toolbelt/browser.py" line="72"/>
        <source>Add URL</source>
        <translation>Ajouter une URL</translation>
    </message>
</context>
</TS>
